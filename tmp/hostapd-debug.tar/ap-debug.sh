#!/usr/bin/env bash
set -euo pipefail

# Colors for output
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
NC="\033[0m"

LOGFILE="/tmp/ap-debug-$(date +%Y%m%d-%H%M%S).log"
INTERFACE="wlan0"
CURRENT_SSID=""
CURRENT_BSSID=""

log() { echo -e "$1" | tee -a "$LOGFILE"; }
section() { log "\n${YELLOW}=== $1 ===${NC}"; }

# Capture current connection for restoration
save_current_connection() {
    section "Saving current WiFi connection"
    CURRENT_SSID=$(iwctl station "$INTERFACE" show 2>/dev/null | grep "Connected network" | awk "{print \$3}" || echo "")
    if [[ -n "$CURRENT_SSID" ]]; then
        log "Currently connected to: $CURRENT_SSID"
    else
        log "No current WiFi connection detected"
    fi
}

restore_connection() {
    section "Restoring WiFi connection"
    
    # Stop any hostapd/dnsmasq we started
    pkill -f "hostapd.*test-hostapd" 2>/dev/null || true
    pkill -f "dnsmasq.*test-dnsmasq" 2>/dev/null || true
    
    # Flush IP and bring interface down
    ip addr flush dev "$INTERFACE" 2>/dev/null || true
    ip link set "$INTERFACE" down 2>/dev/null || true
    
    # Restart iwd and NetworkManager
    systemctl restart iwd
    sleep 2
    systemctl restart NetworkManager
    sleep 3
    
    # Reconnect to saved network
    if [[ -n "$CURRENT_SSID" ]]; then
        log "Reconnecting to $CURRENT_SSID..."
        nmcli device wifi connect "$CURRENT_SSID" 2>&1 | tee -a "$LOGFILE" || true
        sleep 5
    fi
    
    # Show final state
    ip addr show "$INTERFACE" 2>&1 | tee -a "$LOGFILE"
}

# Trap to restore on exit/error
trap restore_connection EXIT

section "AP Debug Script Started"
log "Log file: $LOGFILE"
log "Date: $(date)"
log "Kernel: $(uname -r)"

section "1. System Information"
log "hostapd version: $(hostapd -v 2>&1 | head -1)"
log "iwd version: $(iwctl --version 2>&1 | head -1 || echo unknown)"
log "NetworkManager version: $(nmcli --version)"
log "libnl version: $(pkg-config --modversion libnl-3.0 2>/dev/null || echo unknown)"

section "2. Wireless Hardware"
lspci -nn | grep -i network | tee -a "$LOGFILE"
log ""
iw dev | tee -a "$LOGFILE"

section "3. Wireless Capabilities"
iw list | head -100 | tee -a "$LOGFILE"

section "4. Regulatory Domain"
iw reg get | tee -a "$LOGFILE"

section "5. Current Network Services State"
log "NetworkManager status:"
systemctl status NetworkManager --no-pager -l 2>&1 | head -20 | tee -a "$LOGFILE"
log ""
log "iwd status:"
systemctl status iwd --no-pager -l 2>&1 | head -20 | tee -a "$LOGFILE"
log ""
log "Running wireless processes:"
ps aux | grep -iE "(hostapd|wpa_supplicant|iwd|NetworkManager)" | grep -v grep | tee -a "$LOGFILE" || true

section "6. Loaded Firmware"
dmesg | grep -i "iwlwifi.*firmware" | tail -5 | tee -a "$LOGFILE"

section "7. Interface State Before Test"
ip addr show "$INTERFACE" | tee -a "$LOGFILE"
iwctl station "$INTERFACE" show 2>&1 | tee -a "$LOGFILE" || true

save_current_connection

section "8. Preparing Interface for AP Mode"

log "Step 8a: Stopping NetworkManager management of $INTERFACE"
nmcli device set "$INTERFACE" managed no 2>&1 | tee -a "$LOGFILE" || true
sleep 1

log "Step 8b: Disconnecting via iwctl"
iwctl station "$INTERFACE" disconnect 2>&1 | tee -a "$LOGFILE" || true
sleep 1

log "Step 8c: Bringing interface down"
ip link set "$INTERFACE" down 2>&1 | tee -a "$LOGFILE"
sleep 1

log "Step 8d: Flushing IP addresses"
ip addr flush dev "$INTERFACE" 2>&1 | tee -a "$LOGFILE"

log "Step 8e: Setting IP for AP mode"
ip addr add 192.168.42.1/24 dev "$INTERFACE" 2>&1 | tee -a "$LOGFILE"

log "Step 8f: Bringing interface up"
ip link set "$INTERFACE" up 2>&1 | tee -a "$LOGFILE"
sleep 2

log "Step 8g: Interface state after setup:"
ip addr show "$INTERFACE" | tee -a "$LOGFILE"
iw dev "$INTERFACE" info 2>&1 | tee -a "$LOGFILE"

section "9. Creating hostapd Test Config"
cat > /tmp/test-hostapd.conf << EOF
interface=$INTERFACE
driver=nl80211
ssid=HyperDebugAP
hw_mode=g
channel=6
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=0

# Debug options
logger_syslog=-1
logger_syslog_level=0
logger_stdout=-1
logger_stdout_level=0
EOF
log "Config written to /tmp/test-hostapd.conf"
cat /tmp/test-hostapd.conf | tee -a "$LOGFILE"

section "10. Running hostapd with Full Debug (10 second test)"
log "${RED}Starting hostapd - watch for crash...${NC}"
timeout 10 hostapd -dd /tmp/test-hostapd.conf 2>&1 | tee -a "$LOGFILE" || {
    EXIT_CODE=$?
    log "${RED}hostapd exited with code: $EXIT_CODE${NC}"
    if [[ $EXIT_CODE -eq 139 ]] || [[ $EXIT_CODE -eq 134 ]]; then
        log "${RED}SIGSEGV or SIGABRT detected!${NC}"
    fi
}

section "11. Checking for Core Dump"
coredumpctl list 2>/dev/null | tail -5 | tee -a "$LOGFILE" || log "No coredumpctl available"

section "12. Kernel Messages During Test"
dmesg | tail -30 | tee -a "$LOGFILE"

section "13. Debug Complete"
log "Full log saved to: $LOGFILE"
log ""
log "${GREEN}Now restoring network connection...${NC}"

# restore_connection is called by trap EXIT
